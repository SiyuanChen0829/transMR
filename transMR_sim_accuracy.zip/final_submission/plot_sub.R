aa<-data.frame()
for (x in c(0,0.5,1,1.5)){
  file_list <- list.files(pattern = paste0("effect05_snpfile_res_betaZX_diff=",x,".RData"))
  file_list <- c(file_list,paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/final_submission/sampleoverlap/",list.files(path="/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/final_submission/sampleoverlap/",
                                      pattern = paste0("*.effect05_snpfile_res_betaZX_diff=",x,".RData"))))
  combined_data <- data.frame()
  # Loop through each RData file
  for (file in file_list) {
    matches <- regmatches(file, regexpr("sampleoverlap\\d+", file))
    if (!length(matches)==0){
      overlapprop <- sub("sampleoverlap", "", matches)
    }else{
      overlapprop <- "0"
    }
    # Load the RData file
    load(file)
    # Extract the data frame
    df <- bbbb
    # Remove rows that are all zero
    df <- df[rowSums(df != 0, na.rm = TRUE) > 0, ]
    df$overlap<-overlapprop
    # Combine the data frames
    combined_data <- rbind(combined_data, na.omit(df))
  }
  combined_data$diff<-x
  aa<-rbind(aa,na.omit(combined_data))
}
aa<-aa[-which(aa$se3==0),]
bb<-aa[,1:3]
colnames(bb)<-c("transMR","IVW","transMR-global IV")
bb$diff<-aa$diff
bb$diff<-as.factor(bb$diff)
bb$overlap<-aa$overlap
bb$overlap[bb$overlap=="01"]<-"0.1"
bb$overlap[bb$overlap=="02"]<-"0.2"
bb$overlap[bb$overlap=="05"]<-"0.5"
# colSums((combined_data[,1:3]-0.5)^2)/nrow(combined_data)
# colSums(combined_data[,4:6]^2)/nrow(combined_data)
# colSums((combined_data[,1:3]-0.5)^2+combined_data[,4:6]^2)/nrow(combined_data)

library(reshape2)
bb<-melt(bb)
colnames(bb)<-c("phi","overlap","method","bias")
bb$bias=bb$bias-0.5
library(ggplot2)
library(ggsci)
library(patchwork)
g1<-ggplot(bb, aes(x = method, y = bias, color=method,fill=overlap)) +
  geom_boxplot() +
  guides(color="none")+
  guides(fill="none")+
  facet_wrap(~ phi, nrow = 2, ncol = 2)+
  theme_bw()+
  scale_fill_manual(values = rep("white", 4))+
  scale_color_npg()+ theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(axis.title.x=element_blank())

bb<-aa[,4:6]^2+(aa[,1:3]-0.5)^2
colnames(bb)<-c("transMR","matchMR","transMR-global IV")
bb$phi<-aa$diff
bb$phi<-as.factor(bb$phi)
#colSums((combined_data[,1:3]-1.5)^2)/nrow(combined_data)
#colSums(combined_data[,4:6]^2)/nrow(combined_data)
#colSums((combined_data[,1:3]-1.5)^2+combined_data[,4:6]^2)/nrow(combined_data)

library(reshape2)
bb<-melt(bb)
colnames(bb)<-c("phi","method","SE")
library(ggplot2)
library(ggsci)
g2 <- ggplot(bb, aes(x=method, y=SE, fill=method, color=method)) + 
  geom_dotplot(binaxis='y', stackdir='center',dotsize=0.5)+
  guides(color="none",fill="none")+stat_summary(fun.data=mean_sdl, fun.args = list(mult=1), 
                                                geom="pointrange",color="black")+
  facet_wrap(~ phi, nrow = 2, ncol = 2)+
  theme_bw()+
  scale_color_npg()+scale_fill_npg()+ theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) + 
  theme(axis.title.x=element_blank())+ 
  ylab("Squared error")

tiff(file="biasSE.tiff",width=2000, height=2000,res=300,type = "cairo")
g1+g2
dev.off()

rp_transMR=rp_IVW=rp_transMRglobalIV<-expand.grid(phi=unique(aa$diff),
                overlap=unique(aa$overlap), theta=0, mse=0, cp=0)

i<-1
for(i in 1:nrow(rp_transMR)){
  cc<-filter(aa,diff==rp_transMR$phi[i]&overlap==rp_transMR$overlap[i])
  rp_transMR$theta[i]<-mean(cc$est1)
  rp_transMR$mse[i]<-mean((cc$est1-0.5)^2+cc$se1^2)
  rp_transMR$cp[i]<-sum((cc$est1+qnorm(0.025)*cc$se1<=0.5)&(cc$est1+qnorm(0.9755)*cc$se1>=0.5))/nrow(cc)
  
  rp_IVW$theta[i]<-mean(cc$est_default)
  rp_IVW$mse[i]<-mean((cc$est_default-0.5)^2+cc$se2^2)
  rp_IVW$cp[i]<-sum((cc$est_default+qnorm(0.025)*cc$se2<=0.5)&(cc$est_default+qnorm(0.9755)*cc$se2>=0.5))/nrow(cc)
  
  rp_transMRglobalIV$theta[i]<-mean(cc$est2)
  rp_transMRglobalIV$mse[i]<-mean((cc$est2-0.5)^2+cc$se3^2)
  rp_transMRglobalIV$cp[i]<-sum((cc$est2+qnorm(0.025)*cc$se3<=0.5)&(cc$est2+qnorm(0.9755)*cc$se3>=0.5))/nrow(cc)
  
}
