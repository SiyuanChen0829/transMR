aa=$1
sbatch <<EOT
#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=48:00:00
#SBATCH --mem=20gb
#SBATCH --partition open
#SBATCH --error /storage/group/dxl46/default/private/siyuan/MR/Application/t1d/final_submission/error0.e
#SBATCH --job-name appl
cd /storage/group/dxl46/default/private/siyuan/MR/Application/t1d/final_submission/;
module load r/4.2.1
Rscript analysis.R ${aa}
EOT