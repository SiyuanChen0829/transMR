library('getopt');
library('data.table');
spec <- matrix(c("joblist","a",2,"character",
                 "maxjob","b",2,"integer",
                 'openq','c',2,'integer'),byrow=T,ncol=4);

A <- getopt(spec);
if(is.null(A$openq)) A$openq <- TRUE;

fname.joblist <- A$joblist;
max.jobs <- A$maxjob;
if(length(max.jobs)==0) max.jobs <- 300;
joblist <- unlist(read.table(fname.joblist,as.is=T,header=F,sep="\t"));
##joblist <- joblist[1:10];
##no.finish <- -1;
##no.finish.new <- 1;
##unlink('finish.txt');
library('R.utils');
##max.jobs <- 300;
ii <- 1;
while (ii<=length(joblist))
    {
        user <- Sys.getenv('USER');
        
        ##jobs.batch <- as.data.frame(fread(cmd=paste0('qstat | grep ',user,' | grep batch '),header=FALSE));
        ##jobs.open <- as.data.frame(fread(cmd=paste0('qstat | grep ',user,'| grep open '),header=FALSE));
        jobs.batch <- as.data.frame(fread(cmd=paste0('squeue | grep ',user,' | grep -v -i open '),header=FALSE));
        jobs.open <- as.data.frame(fread(cmd=paste0('squeue | grep ',user,'| grep open '),header=FALSE));
        ##print(no.jobs);
        
        
        no.running.open <- 0;
        no.running.batch <- 0;
        if(nrow(jobs.open)>0) {
            no.running.open <- length(which(jobs.open[,5]=='R'));
            ##if(length(no.running.open)==0) no.running.open <- 0
        }
        if(nrow(jobs.batch)>0) {
            no.running.batch <- length(which(jobs.batch[,5]=='R'));
            ##if(length(no.running.batch)==0) no.running.batch <- 0;
        }

        ##if open queue is not used up, use it;
        if(A$openq==TRUE) {
            if(no.running.open<100) {
                for(jj in ii:min((ii+100-no.running.open),nrow(joblist)))
                    {
                        print(joblist[jj]);
                        job.q <- paste0(joblist[jj],' open');
                        system(job.q);
                    }
                ii <- (ii+100-no.running.open)+1;
            }
            if(no.running.batch<max.jobs) {
                for(jj in ii:min((ii+max.jobs-no.running.batch),nrow(joblist)))
                    {
                        print(joblist[jj]);
                        job.q <- paste0(joblist[jj],' dxl46_bc');
                        system(job.q);
                    }
                ii <- (ii+max.jobs-no.running.batch)+1;

            }
            
        }
        if(A$openq==FALSE) {
            if(no.running.batch<max.jobs) {
                for(jj in ii:min((ii+max.jobs-no.running.batch),nrow(joblist)))
                    {
                        print(joblist[jj]);
                        job.q <- paste0(joblist[jj],' dxl46_bc');
                        system(job.q);
                    }
                ii <- (ii+max.jobs-no.running.batch)+1;
                
            }
            
        }

        Sys.sleep(120);
    }
