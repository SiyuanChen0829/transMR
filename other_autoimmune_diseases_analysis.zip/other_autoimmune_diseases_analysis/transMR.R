i<-1
predict.betax<-numeric(nrow(sub_eqtl))
names(predict.betax)<-sub_gwas$snpid
se.predict<-numeric(nrow(sub_eqtl))
lambdas<-exp(seq(-3,3,by=0.5))#c(0.01,0.5,1,5,10)
for (i in 1:length(predict.betax)){
  df<-data.frame(beta=c(sub_eqtl$V3[i],eqtl.AFR$V3[i],eqtl.HIS$V3[i],eqtl.EUR$V3[i]),
                 pc1=pca[["x"]][1:4,1],
                 pc2=pca[["x"]][1:4,2],
                 pc3=pca[["x"]][1:4,3],
                 weights=c(1/sub_eqtl$se[i]^2,1/eqtl.AFR$se[i]^2,1/eqtl.HIS$se[i]^2,1/eqtl.EUR$se[i]^2))
  se_selection=sub_eqtl$se[i]
  ind_selection<-1
  if(npc>1){
    if(npc==2){
      X<-as.matrix(cbind(c(1,1,1,1),scale(df[,2])))
      y<-scale(df$beta)
      mean_beta<-mean(df$beta)
      sd_beta<-sd(df$beta)
      mean_pcs<-apply(as.matrix(df[,2]),2,mean)
      sd_pcs<-apply(as.matrix(df[,2]),2,sd)
      #lm1<-glmnet(df[,2],df[,1],weights = df$weights,alpha=0,lambda=c(0.01,0.5,1,5,10))
      res<-tuned_ridge(lambdas,rep(0,npc))
      eta_biased<-res$eta
      lambda_final<-res$lambda
      eta_debiased<-eta_biased+lambda_final*ginv(t(X)%*%X+lambda_final*diag(2))%*%eta_biased
      eta_final<-eta_debiased
      new_X<-as.matrix(c(1,(as.numeric(df6[1,1])-mean_pcs)/sd_pcs))
      predict.betax[i]<-t(new_X)%*%eta_final*sd_beta+mean_beta
      C<-ginv(t(X)%*%X+lambda_final*diag(ncol(X)))%*%(diag(ncol(X))+lambda_final*ginv(t(X)%*%X+lambda_final*diag(ncol(X))))
      se.predict[i]<-sd_beta^2*t(new_X)%*%C%*%new_X
    }
    if(npc==3){
      X<-as.matrix(cbind(c(1,1,1,1),scale(df[,2:3])))
      y<-scale(df$beta)
      mean_beta<-mean(df$beta)
      sd_beta<-sd(df$beta)
      mean_pcs<-apply(as.matrix(df[,2:3]),2,mean)
      sd_pcs<-apply(as.matrix(df[,2:3]),2,sd)
      lm1<-glmnet(df[,2:3],df[,1],weights = df$weights,alpha=0,lambda=c(0.01,0.5,1,5,10))
      res<-tuned_ridge(lambdas,coef(lm1)[,5])
      eta_biased<-res$eta
      lambda_final<-res$lambda
      eta_debiased<-eta_biased+lambda_final*ginv(t(X)%*%X+lambda_final*diag(3))%*%eta_biased
      eta_final<-eta_debiased
      new_X<-as.matrix(c(1,(as.numeric(df6[1,1])-mean_pcs)/sd_pcs))
      predict.betax[i]<-t(new_X)%*%eta_final*sd_beta+mean_beta
      C<-ginv(t(X)%*%X+lambda_final*diag(ncol(X)))%*%(diag(ncol(X))+lambda_final*ginv(t(X)%*%X+lambda_final*diag(ncol(X))))
      se.predict[i]<-sd_beta^2*t(new_X)%*%C%*%new_X
    }
  }else{
    b1<-weighted.mean(df[,1],weights = df$weights)
    predict.betax[i]<-b1
    se.predict[i]<-1/(sum(df$weights))
  }
}
pvalue.predict<-2*pt(q=-abs(predict.betax/se.predict), df=2)
