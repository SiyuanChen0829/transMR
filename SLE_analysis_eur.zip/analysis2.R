###############################################
i<-1
predict.betax<-numeric(nrow(sub_eqtl))
names(predict.betax)<-sub_gwas$snpid
se.predict<-numeric(nrow(sub_eqtl))

for (i in 1:length(predict.betax)){
  df<-data.frame(beta=c(sub_eqtl$V3[i],eqtl.AFR$V3[i],eqtl.HIS$V3[i],eqtl.CHN$V3[i]),
                 pc1=pca[["x"]][1:4,1],
                 pc2=pca[["x"]][1:4,2],
                 pc3=pca[["x"]][1:4,3],
                 weights=c(1/sub_eqtl$se[i]^2,1/eqtl.AFR$se[i]^2,1/eqtl.HIS$se[i]^2,1/eqtl.CHN$se[i]^2))
  if(npc>1){
  if(npc==2){
    lm1<-lm(beta~pc1,data=df,weights = df$weights)
    b1<-predict(lm1,newdata=df6[1,1:2], se.fit = TRUE)
    predict.betax[i]<-b1$fit
    se.predict[i]<-b1$se.fit
  }
  if(npc==3){
    lm1<-glmnet(df[,2:3],df[,1],alpha=0,lambda=c(0.01,0.5,1,2,10),weights = df$weights)
    b1<-predict(lm1,newx=as.matrix(df6[1,1:2]))[which.max(lm1$dev.ratio)]
  
  predict.betax[i]<-b1
  lm2<-lm(beta~pc1+pc2,data=df,weights = df$weights)
  lmd<-c(0.01,0.5,1,2,10)[which.max(lm1$dev.ratio)]
  X<-as.matrix(cbind(c(1,1,1,1),df[,2:3]))
  LO<-solve(t(X)%*%X+lmd*diag(3))%*%t(X)%*%X
  var_beta<-LO%*%vcov(lm2)%*%t(LO)
  new_X<-as.matrix(c(1,as.numeric(df6[1,1:2])))
  se.predict[i]<-sqrt(t(new_X)%*%var_beta%*%new_X)
  }
  }else{
    b1<-weighted.mean(df[,1],weights = df$weights)
    predict.betax[i]<-b1
    se.predict[i]<-1/(sum(df$weights))
  }
  
  #lm1<-lm(beta~pc1+pc2+pc3,weights = weights, data = df)
  #b1<-predict(lm1,newdata=df6)
  
 
}
#pvalue.predict<-2*pt(q=abs(predict.betax/se.predict), df=1,lower.tail = FALSE)
pvalue.predict<-2*pt(q=-abs(predict.betax/se.predict), df=2)
