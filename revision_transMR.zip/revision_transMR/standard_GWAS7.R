sumstats<-function(cohort1,snpfile,tr){
  cohort1$scanID<-c(1:nrow(cohort1))
  cohort1$pheno<-cohort1[,tr]
  scanAnnot <- ScanAnnotationDataFrame(cohort1[,c("scanID","pheno")])
  geno <- MatrixGenotypeReader(genotype = t(cohort1[,1:nrow(snpfile)]), snpID = c(1:nrow(snpfile)),
                               chromosome = snpfile$CHR, position = snpfile$BP,
                               scanID = c(1:nrow(cohort1)))
  genoData <- GenotypeData(geno,scanAnnot=scanAnnot)
  genoIterator <- GenotypeBlockIterator(genoData, snpBlock=500)
  nullmod <- fitNullModel(genoIterator, outcome="pheno")
  assoc <- assocTestSingle(genoIterator, null.model = nullmod,BPPARAM=BiocParallel::SerialParam())
  ss<-data.frame(snp=paste0("X",assoc$chr,".",assoc$pos),allFreq=assoc$freq,pValue=assoc$Score.pval,
                 effect=assoc$Est,effectSe=assoc$Est.SE)
  return(ss)
}

ss1<-sumstats(c1,snpfile,"X")
ss2<-sumstats(c2,snpfile,"X")
ss3<-sumstats(c3,snpfile,"X")
ss4<-sumstats(c4,snpfile,"X")
ss5<-sumstats(c5,snpfile,"X")
ss6<-sumstats(c6,snpfile,"Y")

ind_available<-intersect(intersect(which(!is.na(ss1$effect)),which(!is.na(ss2$effect))),which(!is.na(ss3$effect)))
ind_available2<-intersect(intersect(which(!is.na(ss4$effect)),which(!is.na(ss5$effect))),which(!is.na(ss6$effect)))
ind_available<-intersect(ind_available,ind_available2)

ss1<-ss1[ind_available,]
ss2<-ss2[ind_available,]
ss3<-ss3[ind_available,]
ss4<-ss4[ind_available,]
ss5<-ss5[ind_available,]
ss6<-ss6[ind_available,]

ind_available<-intersect(intersect(ss1$snp,ss2$snp),ss3$snp)
ind_available2<-intersect(intersect(ss4$snp,ss5$snp),ss6$snp)
ind_available<-intersect(ind_available,ind_available2)

ss1<-ss1[match(ind_available,ss1$snp),]
ss2<-ss2[match(ind_available,ss2$snp),]
ss3<-ss3[match(ind_available,ss3$snp),]
ss4<-ss4[match(ind_available,ss4$snp),]
ss5<-ss5[match(ind_available,ss5$snp),]
ss6<-ss6[match(ind_available,ss6$snp),]

ss1_IV<-filter(ss1,pValue<1e-3)
ss2_IV<-filter(ss2,pValue<1e-3)
ss3_IV<-filter(ss3,pValue<1e-3)
ss4_IV<-filter(ss4,pValue<1e-3)
ss5_IV<-filter(ss5,pValue<1e-3)
ss6_IV<-filter(ss6,snp %in% unique(c(ss1_IV$snp))) #matched ancestry!

ss1_IV$strength<-ss1_IV$effect^2/ss1_IV$effectSe^2
ss2_IV$strength<-ss2_IV$effect^2/ss2_IV$effectSe^2
ss3_IV$strength<-ss3_IV$effect^2/ss3_IV$effectSe^2
ss4_IV$strength<-ss4_IV$effect^2/ss4_IV$effectSe^2
ss5_IV$strength<-ss5_IV$effect^2/ss5_IV$effectSe^2

#ss1_IV<-filter(ss1_IV,strength>10)
#ss2_IV<-filter(ss2_IV,strength>10)
#ss3_IV<-filter(ss3_IV,strength>10)
#ss4_IV<-filter(ss4_IV,strength>10)
#ss5_IV<-filter(ss5_IV,strength>10)

sig_snp<-intersect(intersect(intersect(ss1_IV$snp,ss2_IV$snp),ss3_IV$snp),intersect(ss4_IV$snp,ss5_IV$snp))
