last_iter<-which(rowSums(opdf)==0)[1]-1
xx<-c(1:ncol(opdf))
opdf<-opdf[1:last_iter,]
sapply(xx,function(x) sum(opdf[,x]<0.05,na.rm=TRUE)/last_iter)
yy<-5:8
ind<-which(!is.na(rowSums(opdf[,5:8])))
sapply(yy,function(x) sum(opdf[ind,x]<0.05,na.rm=TRUE)/length(ind))

