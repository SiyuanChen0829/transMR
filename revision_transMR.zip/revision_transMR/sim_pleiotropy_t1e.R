library(dbplyr,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(dplyr,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")

library(GENESIS,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(GWASTools,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(MASS)
library(MendelianRandomization,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(MRcML,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(optimx,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
source("/storage/group/dxl46/default/private/siyuan/MR/revision_transMR/wcc.R")
args = commandArgs(trailingOnly=TRUE)
x = as.numeric(args[1])
x<-x/2
snpfile<-read.delim("/storage/group/dxl46/default/private/siyuan/MR/SNP.txt", header = TRUE, sep = "\t", dec = ".")
snpfile<-na.omit(snpfile)
snpfile<-snpfile %>% mutate(SNP=paste0(CHR,":",BP))
snpfile<-unique(snpfile,by="RSID")


load("/storage/group/dxl46/default/private/siyuan/MR/ref_AF_hg19.RData")
ref_AF <- ref %>% mutate(SNP=paste0(CHROM,":",POS))
ref_AF$EAS_AF<-as.numeric(ref_AF$EAS_AF)
ref_AF$AMR_AF<-as.numeric(ref_AF$AMR_AF)
ref_AF$AFR_AF<-as.numeric(ref_AF$AFR_AF)
ref_AF$EUR_AF<-as.numeric(ref_AF$EUR_AF)
ref_AF$SAS_AF<-as.numeric(ref_AF$SAS_AF)
ref_AF<-na.omit(ref_AF)
ref_AF<-ref_AF %>% filter(EAS_AF+EUR_AF+AFR_AF>0.1)

snpfile <-snpfile %>%filter(SNP %in% ref_AF$SNP)
snpfile<-snpfile%>%mutate(SNPname=paste0("X",CHR,".",BP))
ref_AF<-ref_AF%>%mutate(SNPname=paste0("X",CHROM,".",POS))
snpfile<-snpfile[match(snpfile$SNPname,ref_AF$SNPname),]

set.seed(700)
snpfile<-snpfile[,1:9]
colnames(snpfile)<-c("SNP","CHR","BP","RSID","Freq_EUR","Freq_AFR","Freq_ASN","Freq_HIS","Freq_BRZ")

#############################check for REF/ALT consistency
i<-1
for (i in 1:nrow(snpfile)){
  if(any((as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])>=0.98)&(as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])<=1.02))){
    snpfile[i,c(5:7)]<-1-snpfile[i,c(5:7)]
    #print(i)
  }
}

n<-5000
colsAF<-c("Freq_EUR","Freq_AFR","Freq_ASN","Freq_HIS","Freq_BRZ")
d<-c(0,x,2*x,0.5*x,0.5*x)

setClass("MyResult", slots = c(Pvalue = "numeric"))
setClass("MyResult2", slots = c(Pvalue.Est = "numeric"))
library(glmnet)
generatecohort<-function(n,i_ans,diffx,cvind,eps){
  cohort1<-data.frame(matrix(ncol=nrow(snpfile)+2,nrow=n, dimnames=list(NULL, c(snpfile$SNP,"Y","X"))))
  i<-1
  af<-snpfile[[i_ans]]
  for(i in 1:nrow(snpfile)){
    cohort1[,i]<-sample(c(0,1,2),size=n,replace=TRUE,prob=c(max(0,1-af[i]-af[i]^2),af[i],af[i]^2))
  }
  U<-rnorm(n,-0.5,2)
  cohort1$X<-rowSums((true_causal_effects_SNP[cvind]+diffx*eps[[i_ans]][cvind])*scale(cohort1[,ind_causal[cvind]]))+0.1*U+rnorm(n)
  cohort1$Y<-rnorm(n)+0.1*U+rowSums(pleiotropy*scale(cohort1[,1:nrow(snpfile)]))
  return(cohort1)
}
opdf<-data.frame(pval_Egger=rep(0,2000),corrected_Egger=rep(0,2000),BIC_Egger=rep(0,2000),meta_Egger=rep(0,2000),
                 pval_lasso=rep(0,2000),corrected_lasso=rep(0,2000),BIC_lasso=rep(0,2000),meta_lasso=rep(0,2000),
                 pval_cml=rep(0,2000),corrected_cml=rep(0,2000),BIC_cml=rep(0,2000),meta_cml=rep(0,2000))
kk<-1
for(kk in 1:2000){
  ob1=ob2=ob3=ob4=NULL
  ind_causal<-sample(1:nrow(snpfile),50)
  cvind.m<-matrix(c(sample(1:50,45),sample(1:50,45),sample(1:50,45),sample(1:50,45),sample(1:50,45)),nrow=5,byrow=TRUE)
  true_causal_effects_SNP<-0.1+rnorm(length(ind_causal),0,0.05)
  rownames(cvind.m)<-colsAF
  pleiotropy<-rnorm(nrow(snpfile),0,0.1)
  
  eps.l<-list()
  eps.l[["Freq_EUR"]]<-rep(0,length(true_causal_effects_SNP))
  eps.l[["Freq_AFR"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[2])
  eps.l[["Freq_ASN"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[3])
  eps.l[["Freq_HIS"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[4])
  eps.l[["Freq_BRZ"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[5])
  ng<-1
  for(ng in 1:50){
    c1<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    c2<-generatecohort(n,colsAF[1],d[1],cvind.m[colsAF[1],],eps.l)
    c3<-generatecohort(n,colsAF[3],d[3],cvind.m[colsAF[3],],eps.l)
    c4<-generatecohort(n,colsAF[4],d[4],cvind.m[colsAF[4],],eps.l)
    c5<-generatecohort(n,colsAF[5],d[5],cvind.m[colsAF[5],],eps.l)
    c6<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    source("/storage/group/dxl46/default/private/siyuan/MR/revision_transMR/standard_GWAS6.R")
    #  cat(paste0("cohort generation iter=",ng," at ", Sys.time(),"\n"),
    #     file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/timerecordfile_diff=",x),append=TRUE)
    if(all(c(nrow(ss1_IV),nrow(ss2_IV),nrow(ss3_IV),nrow(ss4_IV),nrow(ss5_IV))>=1)&(nrow(ss1_IV)>=3)){break}
  }
  
  snp_causal<-snpfile$SNPname[ind_causal]
  ind<-match(ss1$snp,ref_AF$SNPname)
  AF3<-ref_AF[ind,6:10]
  AF4<-t(AF3)
  aa<-rbind(ss1$allFreq,ss2$allFreq,ss3$allFreq,ss4$allFreq,ss5$allFreq,ss6$allFreq,AF4)
  pca<-prcomp(aa,center=TRUE,scale=TRUE)
  df6<-data.frame(pc1=pca[["x"]][6,1],pc2=pca[["x"]][6,2],pc3=pca[["x"]][6,3])
  IVs<-unique(ss1_IV$snp)
  
  ############################### winner's curse corrected, debiased #########################
  predict.betax.dev<-numeric(length(IVs))
  se.predict.dev<-numeric(length(IVs))
  names(predict.betax.dev)<-IVs
  i<-1
  for(i in 1:length(IVs)){
    ind<-which(ss1$snp==IVs[i])
    df<-data.frame(beta=c(ss1$effect[ind],ss2$effect[ind],ss3$effect[ind],ss4$effect[ind],ss5$effect[ind]),
                   weights=c(1/ss1$effectSe[ind]^2,1/ss2$effectSe[ind]^2,1/ss3$effectSe[ind]^2,1/ss4$effectSe[ind]^2,1/ss5$effectSe[ind]^2),
                   zscore=c(ss1$effect[ind]/ss1$effectSe[ind],
                            ss2$effect[ind]/ss2$effectSe[ind],
                            ss3$effect[ind]/ss3$effectSe[ind],
                            ss4$effect[ind]/ss4$effectSe[ind],
                            ss5$effect[ind]/ss5$effectSe[ind]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3])
    se1=ss1$effectSe[ind]
    X<-as.matrix(cbind(c(1,1,1,1,1),scale(df[,4:6])))
    y<-scale(df$beta)
    mean_beta<-mean(df$beta)
    sd_beta<-sd(df$beta)
    mean_pcs<-apply(as.matrix(df[,4:6]),2,mean)
    sd_pcs<-apply(as.matrix(df[,4:6]),2,sd)
    scaled_weights<-df$weights/sum(df$weights)*length(df$weights)
    lm1<-glmnet(df[,4:6],df[,1],weights = df$weights,alpha=0,lambda=exp(seq(-3,3,by=1))) 
    res<-tuned_ridge_dev(exp(seq(-3,3,by=1)),coef(lm1)[,ncol(coef(lm1))])
    eta_biased<-res$eta
    lambda_final<-res$lambda
    #eta_debiased<-eta_biased+lambda_final*ginv(t(X)%*%X+lambda_final*diag(4))%*%eta_biased
    eta_debiased<-eta_biased#+ginv(t(X)%*%X)%*%t(X)%*%(y-X%*%eta_biased)
    eta_final<-eta_debiased
    new_X<-as.matrix(c(1,(as.numeric(df6[1,1:3])-mean_pcs)/sd_pcs))
    predict.betax.dev[i]<-t(new_X)%*%eta_final*sd_beta+mean_beta

    wts <- scaled_weights
    beta_hat <-  eta_final
    lambda_best <- lambda_final
    y_hat <- X %*% beta_hat
    resid <- y - y_hat
    sigma2_hat <- sum(wts * resid^2) / sum(wts)
    # Approximate prediction variance
    XtWX <- t(X) %*% (wts * X)
    ridge_cov <- sigma2_hat * solve(XtWX + lambda_best * diag(ncol(X)))
    var_b1 <- t(new_X) %*% ridge_cov %*% as.numeric(new_X)
    se.predict.dev[i] <- sqrt(var_b1 *sd_beta^2)
  }
  ############################### winner's curse corrected, BIC, debiased #########################
  predict.betax.BIC<-numeric(length(IVs))
  se.predict.BIC<-numeric(length(IVs))
  names(predict.betax.BIC)<-IVs
  i<-1
  for(i in 1:length(IVs)){
    ind<-which(ss1$snp==IVs[i])
    df<-data.frame(beta=c(ss1$effect[ind],ss2$effect[ind],ss3$effect[ind],ss4$effect[ind],ss5$effect[ind]),
                   weights=c(1/ss1$effectSe[ind]^2,1/ss2$effectSe[ind]^2,1/ss3$effectSe[ind]^2,1/ss4$effectSe[ind]^2,1/ss5$effectSe[ind]^2),
                   zscore=c(ss1$effect[ind]/ss1$effectSe[ind],
                            ss2$effect[ind]/ss2$effectSe[ind],
                            ss3$effect[ind]/ss3$effectSe[ind],
                            ss4$effect[ind]/ss4$effectSe[ind],
                            ss5$effect[ind]/ss5$effectSe[ind]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3])
    se1<-ss1$effectSe[ind]
    X<-as.matrix(cbind(c(1,1,1,1,1),scale(df[,4:6])))
    y<-scale(df$beta)
    mean_beta<-mean(df$beta)
    sd_beta<-sd(df$beta)
    mean_pcs<-apply(as.matrix(df[,4:6]),2,mean)
    sd_pcs<-apply(as.matrix(df[,4:6]),2,sd)
    scaled_weights<-df$weights/sum(df$weights)*length(df$weights)
    lm1<-glmnet(df[,4:6],df[,1],weights = df$weights,alpha=0,lambda=exp(seq(-3,3,by=1))) 
    res<-tuned_ridge_BIC(exp(seq(-3,3,by=1)),coef(lm1)[,ncol(coef(lm1))])
    eta_biased<-res$eta
    lambda_final<-res$lambda
    eta_debiased<-eta_biased#+lambda_final*ginv(t(X)%*%X+lambda_final*diag(4))%*%eta_biased
    eta_final<-eta_debiased
    new_X<-as.matrix(c(1,(as.numeric(df6[1,1:3])-mean_pcs)/sd_pcs))
    predict.betax.BIC[i]<-t(new_X)%*%eta_final*sd_beta+mean_beta
    
    wts <- scaled_weights
    beta_hat <-  eta_final
    lambda_best <- lambda_final
    y_hat <- X %*% beta_hat
    resid <- y - y_hat
    sigma2_hat <- sum(wts * resid^2) / sum(wts)
    # Approximate prediction variance
    XtWX <- t(X) %*% (wts * X)
    ridge_cov <- sigma2_hat * solve(XtWX + lambda_best * diag(ncol(X)))
    var_b1 <- t(new_X) %*% ridge_cov %*% as.numeric(new_X)
    se.predict.BIC[i] <- sqrt(var_b1 *sd_beta^2)
  }
  ########################### meta regression only ################################
  predict.betax2<-numeric(length(IVs))
  se.predict2<-numeric(length(IVs))
  names(predict.betax2)<-IVs
  i<-1
  for (i in 1:length(predict.betax2)){
    ind<-which(ss1$snp==IVs[i])
    df<-data.frame(beta=c(ss1$effect[ind],ss2$effect[ind],ss3$effect[ind],ss4$effect[ind],ss5$effect[ind]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3],
                   weights=c(1/ss1$effectSe[ind]^2,1/ss2$effectSe[ind]^2,1/ss3$effectSe[ind]^2,1/ss4$effectSe[ind]^2,1/ss5$effectSe[ind]^2))
    lm1<-glmnet(data.matrix(df[,2:4]),df[,1],weights = df$weights,alpha=0,lambda=exp(seq(-3,3,by=0.5)))
    b1<-predict(lm1,newx=as.matrix(df6[1,]))[which.max(lm1$dev.ratio)]
    predict.betax2[i]<-b1
    X <- as.matrix(df[, 2:4])
    y <- df[, 1]
    wts <- df$weights
    beta_hat <- lm1$beta[, which.max(lm1$dev.ratio)]
    lambda_best <- lm1$lambda[which.max(lm1$dev.ratio)]
    y_hat <- X %*% beta_hat
    resid <- y - y_hat
    sigma2_hat <- sum(wts * resid^2) / sum(wts)
    
    # Approximate prediction variance
    XtWX <- t(X) %*% (wts * X)
    ridge_cov <- sigma2_hat * solve(XtWX + lambda_best * diag(ncol(X)))
    var_b1 <- t(as.numeric(as.matrix(df6[1,]))) %*% ridge_cov %*% as.numeric(as.matrix(df6[1,]))
    se.predict2[i] <- sqrt(var_b1)
    
  }
  ob1<-mr_input(bx = ss1_IV$effect, bxse = ss1_IV$effectSe, by = ss6_IV$effect, byse = ss6_IV$effectSe,
                exposure = "exposure",outcome = "outcome",snps = "snp")
  ob2<-mr_input(bx = predict.betax.dev, bxse = se.predict.dev, by = ss6_IV$effect, byse = ss6_IV$effectSe,
                exposure = "exposure",outcome = "outcome",snps = "snp")
  ob3<-mr_input(bx = predict.betax.BIC, bxse = se.predict.BIC, by = ss6_IV$effect, byse = ss6_IV$effectSe,
  exposure = "exposure",outcome = "outcome",snps = "snp")
  ob4<-mr_input(bx = predict.betax2, bxse = se.predict2, by = ss6_IV$effect, byse = ss6_IV$effectSe,
                exposure = "exposure",outcome = "outcome",snps = "snp")
  
  r1  <- tryCatch({
    mr_egger(ob1)}, error = function(e) {
      new("MyResult2", Pvalue.Est = NA_real_)
    })
  r2  <- tryCatch({
    mr_egger(ob2)}, error = function(e) {
      new("MyResult2", Pvalue.Est = NA_real_)
    })
  r3  <- tryCatch({
    mr_egger(ob3)}, error = function(e) {
      new("MyResult2", Pvalue.Est = NA_real_)
    })
  r4  <- tryCatch({
    mr_egger(ob4)}, error = function(e) {
      new("MyResult2", Pvalue.Est = NA_real_)
    })
  r5 <- tryCatch({
    mr_lasso(ob1)}, error = function(e) {
      new("MyResult", Pvalue = NA_real_)
    })
  r6  <- tryCatch({
    mr_lasso(ob2)}, error = function(e) {
      new("MyResult", Pvalue = NA_real_)
    })
  r7  <- tryCatch({
    mr_lasso(ob3)}, error = function(e) {
      new("MyResult", Pvalue = NA_real_)
    })
  r8  <- tryCatch({
    mr_lasso(ob4)}, error = function(e) {
      new("MyResult", Pvalue = NA_real_)
    })
  r9  <- tryCatch({
    mr_cML(ss1_IV$effect, ss6_IV$effect, ss1_IV$effectSe, ss6_IV$effectSe, n=5000, random_start=100)},error = function(e) {
      list(MA_BIC_p = NA_real_)
    })
  
  r10 <- tryCatch({
    mr_cML(predict.betax.dev, ss6_IV$effect, se.predict.dev, ss6_IV$effectSe, n=5000, random_start=100)},error = function(e) {
      list(MA_BIC_p = NA_real_)
    })
  
  r11 <- tryCatch({
    mr_cML(predict.betax.BIC, ss6_IV$effect, se.predict.BIC, ss6_IV$effectSe, n=5000, random_start=100)},error = function(e) {
      new("MyResult2", MA_BIC_p = NA_real_)
    })
  
  r12 <- tryCatch({
    mr_cML(predict.betax2, ss6_IV$effect, se.predict2, ss6_IV$effectSe, n=5000, random_start=100)},error = function(e) {
      list(MA_BIC_p = NA_real_)
    })
  
  
  opdf[kk,]<-c(r1@Pvalue.Est,r2@Pvalue.Est,r3@Pvalue.Est,r4@Pvalue.Est,
               r5@Pvalue,r6@Pvalue,r7@Pvalue,r8@Pvalue,
    r9$MA_BIC_p,r10$MA_BIC_p,r11$MA_BIC_p,r12$MA_BIC_p)
   save(opdf,file=paste0("/storage/group/dxl46/default/private/siyuan/MR/revision_transMR/pleiotropy_t1e/t1e_pleiotrpy_methods_diff=",x,".RData"))
}
