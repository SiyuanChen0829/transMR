last_iter<-which(rowSums(opdf)==0)[1]-1
if(is.na(last_iter)){last_iter<-nrow(opdf)}
xx<-c(1,3,5,7,9,11)
sapply(xx,function(a) mean(opdf[1:last_iter,a]-0.5,na.rm=TRUE))

xx<-c(1,3,5,7,9,11)
sapply(xx,function(a) mean((opdf[1:last_iter,a]-0.5)^2+(opdf[1:last_iter,a]-mean(opdf[1:last_iter,a]))^2))

xx<-c(1,3,5,7,9)
sapply(xx,function(a) sum((opdf[1:last_iter,a]-qnorm(0.975)*opdf[1:last_iter,a+1]<0.5) & (opdf[1:last_iter,a]+qnorm(0.975)*opdf[1:last_iter,a+1]>0.5))/last_iter)



xx<-c(1,3,5,7,9,11,13,15,17,19,21,23)
sapply(xx,function(a) mean(opdf[1:last_iter,a]-0.5,na.rm=TRUE))
sapply(xx,function(a) mean((opdf[1:last_iter,a]-0.5)^2+opdf[1:last_iter,a+1]^2, na.rm=TRUE))
sapply(xx,function(a) sum((opdf[1:last_iter,a]-qnorm(0.975)*opdf[1:last_iter,a+1]<0.5) & (opdf[1:last_iter,a]+qnorm(0.975)*opdf[1:last_iter,a+1]>0.5),na.rm=TRUE)/last_iter)

last_iter<-which(rowSums(opdf)==0)[1]-1
xx<-c(1,3,5,7,9)
1-sapply(xx,function(a) sum((opdf[1:last_iter,a]-qnorm(0.975)*opdf[1:last_iter,a+1]<0) & (opdf[1:last_iter,a]+qnorm(0.975)*opdf[1:last_iter,a+1]>0))/last_iter)

last_iter<-which(rowSums(opdf)==0)[1]-1
xx<-c(1,3,5,7,9)
sapply(xx,function(a) sum(opdf[1:last_iter,a]^2/opdf[1:last_iter,a+1]^2>qchisq(0.95,1))/last_iter)

