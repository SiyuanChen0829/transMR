ridge_log_likelihood <- function(w, X, y, lambda, weights) {
  n0 <- length(y)
  residuals <- y - X %*% w
  weighted_residuals_sq <- weights * (residuals^2)
  sigma2 <- sum(weighted_residuals_sq) / sum(weights)
  prob<-rep(1,n0)
  #w_c<-w+lambda*ginv(t(X)%*%X+lambda*diag(4))%*%w
  w_c<-w#+ginv(t(X)%*%X)%*%t(X)%*%(y-X%*%w)
  mu1<-(X[1,] %*% w_c)*sd_beta+mean_beta
  c<-qnorm(1-(1e-3)/2)
  prob[1]<-pnorm(-c+abs(mu1/se1))+pnorm(-c-abs(mu1/se1))
  pl<-(-n0/2*log(2*pi*sigma2)-sum(weights*(residuals^2/2/sigma2+log(prob)))-(lambda/2)*sum(w[-1]^2))
  return(-pl)
}
tuned_ridge_dev <- function(lambda_vec, initial_eta) {
  d <- numeric(length(lambda_vec))
  n0 <- length(y)
  etas <- list()
  for (i in seq_along(lambda_vec)) {
    fit_ridge <- optimx(par = initial_eta,
                        fn = ridge_log_likelihood,
                        method = "BFGS",
                        X = X, y = y,
                        lambda = lambda_vec[i],
                        weights = scaled_weights)
    
    eta <- as.numeric(fit_ridge[1, 1:4])
    etas[[i]] <- eta
    
    # recompute sigma2 and loglik (without penalty)
    residuals <- y - X %*% eta
    dev <- mean(residuals^2)
    d[i] <- -dev  # maximize loglik = minimize dev
  }
  
  best_idx <- which.max(d)
  res <- list(lambda = lambda_vec[best_idx],
              eta = etas[[best_idx]],
              dev = -d)
  return(res)
}

tuned_ridge_BIC <- function(lambda_vec, initial_eta) {
  d <- numeric(length(lambda_vec))
  etas <- list()
  n0 <- length(y)
  
  for (i in seq_along(lambda_vec)) {
    fit_ridge <- optimx(par = initial_eta,
                        fn = ridge_log_likelihood,
                        method = "BFGS",
                        X = X, y = y,
                        lambda = lambda_vec[i],
                        weights = scaled_weights)
    
    eta <- as.numeric(fit_ridge[1, 1:4])
    etas[[i]] <- eta
    bic <- log(n0) * sum(abs(eta)>1e-3) - 2 * (-fit_ridge$value)
    d[i] <- bic
  }
  
  best_idx <- which.min(d)
  res <- list(lambda = lambda_vec[best_idx],
              eta = etas[[best_idx]],
              BIC = d)
  return(res)
}

