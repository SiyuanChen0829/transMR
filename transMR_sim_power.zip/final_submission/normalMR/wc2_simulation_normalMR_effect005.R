library(GENESIS,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(GWASTools,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(MASS)
source("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/wcc2.R")
args = commandArgs(trailingOnly=TRUE)
x = as.numeric(args[1])
x<-x/2

library(dplyr)
snpfile<-read.delim("/storage/group/dxl46/default/private/siyuan/MR/SNP.txt", header = TRUE, sep = "\t", dec = ".")
snpfile<-na.omit(snpfile)
snpfile<-snpfile %>% mutate(SNP=paste0(CHR,":",BP))
snpfile<-unique(snpfile,by="RSID")


load("/storage/group/dxl46/default/private/siyuan/MR/ref_AF_hg19.RData")
ref_AF <- ref %>% mutate(SNP=paste0(CHROM,":",POS))
ref_AF$EAS_AF<-as.numeric(ref_AF$EAS_AF)
ref_AF$AMR_AF<-as.numeric(ref_AF$AMR_AF)
ref_AF$AFR_AF<-as.numeric(ref_AF$AFR_AF)
ref_AF$EUR_AF<-as.numeric(ref_AF$EUR_AF)
ref_AF$SAS_AF<-as.numeric(ref_AF$SAS_AF)
ref_AF<-na.omit(ref_AF)
ref_AF<-ref_AF %>% filter(EAS_AF+EUR_AF+AFR_AF>0.1)

snpfile <-snpfile %>%filter(SNP %in% ref_AF$SNP)

set.seed(259)
snpfile<-snpfile[,1:9]
colnames(snpfile)<-c("SNP","CHR","BP","RSID","Freq_EUR","Freq_AFR","Freq_ASN","Freq_HIS","Freq_BRZ")

#############################check for REF/ALT consistency
i<-1
for (i in 1:nrow(snpfile)){
  if(any((as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])>=0.98)&(as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])<=1.02))){
    snpfile[i,c(5:7)]<-1-snpfile[i,c(5:7)]
    #print(i)
  }
}

n<-20000
colsAF<-c("Freq_EUR","Freq_AFR","Freq_ASN","Freq_HIS","Freq_BRZ")
d<-c(0,x,2*x,0.5*x,1.5*x)

library(glmnet)
generatecohort<-function(n,i_ans,diffx,cvind,eps){
  cohort1<-data.frame(matrix(ncol=nrow(snpfile)+2,nrow=n, dimnames=list(NULL, c(snpfile$SNP,"Y","X"))))
  i<-1
  af<-snpfile[[i_ans]]
  for(i in 1:nrow(snpfile)){
    cohort1[,i]<-sample(c(0,1,2),size=n,replace=TRUE,prob=c(max(0,1-af[i]-af[i]^2),af[i],af[i]^2))
  }
  U<-rnorm(n,-0.5,2)
  cohort1$X<-rowSums((true_causal_effects_SNP[cvind]+diffx*eps[[i_ans]][cvind])*scale(cohort1[,ind_causal[cvind]]))+0.1*U+rnorm(n)
  #cohort1$X<-rowSums((true_causal_effects_SNP[cvind]+diffx*rnorm(length(true_causal_effects_SNP[cvind]),0,0.25))*cohort1[,ind_causal[cvind]])+0.1*U+rnorm(n)
  cohort1$Y<-0.05*cohort1$X+rnorm(n)+0.1*U
  return(cohort1)
}

opdf<-data.frame(theta_corrected=rep(0,5000),se_corrected=rep(0,5000),
                 theta_meta=rep(0,5000),se_meta=rep(0,5000),
                 theta_IVW_2S=rep(0,5000),se_IVW_2S=rep(0,5000),
                 theta_IVW_3S=rep(0,5000),se_IVW_3S=rep(0,5000))
kk<-1
for (kk in 1:5000){
  #for (kk in 1:500){
  ind_causal<-sample(1:nrow(snpfile),25)
  cvind.m<-matrix(c(sample(1:25,20),sample(1:25,20),sample(1:25,20),sample(1:25,20),sample(1:25,20)),nrow=5,byrow=TRUE)
  true_causal_effects_SNP<-abs(0.1+rnorm(length(ind_causal),0,0.05))
  rownames(cvind.m)<-colsAF
  eps.l<-list()
  eps.l[["Freq_EUR"]]<-rep(0,length(true_causal_effects_SNP))
  eps.l[["Freq_AFR"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[2])
  eps.l[["Freq_ASN"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[3])
  eps.l[["Freq_HIS"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[4])
  eps.l[["Freq_BRZ"]]<-rnorm(length(true_causal_effects_SNP),0,0.02*d[5])
  ng<-1
  for(ng in 1:25){
    c1<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    c2<-generatecohort(n,colsAF[1],d[1],cvind.m[colsAF[1],],eps.l)
    c3<-generatecohort(n,colsAF[3],d[3],cvind.m[colsAF[3],],eps.l)
    c4<-generatecohort(n,colsAF[4],d[4],cvind.m[colsAF[4],],eps.l)
    c5<-generatecohort(n,colsAF[5],d[5],cvind.m[colsAF[5],],eps.l)
    c6<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    c7<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    source("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/standard_GWAS6.R")
    ss7<-sumstats(c7,snpfile,"X")
    ss7_IV<-filter(ss7,pValue<1e-3)
    #  cat(paste0("cohort generation iter=",ng," at ", Sys.time(),"\n"),
    #     file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/timerecordfile_diff=",x),append=TRUE)
    if(all(c(nrow(ss1_IV),nrow(ss2_IV),nrow(ss3_IV),nrow(ss4_IV),nrow(ss5_IV))>=1)&(nrow(ss1_IV)>=3)){break}
  }
  snpfile<-snpfile%>%mutate(SNPname=paste0("X",CHR,".",BP))
  ref_AF<-ref_AF%>%mutate(SNPname=paste0("X",CHROM,".",POS))
  snpfile<-snpfile[match(snpfile$SNPname,ref_AF$SNPname),]
  snp_causal<-snpfile$SNPname[ind_causal]
  ind<-match(ss1$snp,ref_AF$SNPname)
  AF3<-ref_AF[ind,6:10]
  AF4<-t(AF3)
  aa<-rbind(ss1$allFreq,ss2$allFreq,ss3$allFreq,ss4$allFreq,ss5$allFreq,ss6$allFreq,AF4)
  pca<-prcomp(aa,center=TRUE,scale=TRUE)
  df6<-data.frame(pc1=pca[["x"]][6,1],pc2=pca[["x"]][6,2],pc3=pca[["x"]][6,3])
  IVs<-unique(c(ss1_IV$snp))
  
  ############################### winner's curse corrected, debiased #########################
  predict.betax<-numeric(length(IVs))
  se.predict<-numeric(length(IVs))
  names(predict.betax)<-IVs
  i<-1
  for(i in 1:length(IVs)){
    ind<-which(ss1$snp==IVs[i])
    df<-data.frame(beta=c(ss1$effect[ind],ss2$effect[ind],ss3$effect[ind],ss4$effect[ind],ss5$effect[ind]),
                   weights=c(1/ss1$effectSe[ind]^2,1/ss2$effectSe[ind]^2,1/ss3$effectSe[ind]^2,1/ss4$effectSe[ind]^2,1/ss5$effectSe[ind]^2),
                   zscore=c(ss1$effect[ind]/ss1$effectSe[ind],
                            ss2$effect[ind]/ss2$effectSe[ind],
                            ss3$effect[ind]/ss3$effectSe[ind],
                            ss4$effect[ind]/ss4$effectSe[ind],
                            ss5$effect[ind]/ss5$effectSe[ind]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3])
    X<-as.matrix(cbind(c(1,1,1,1,1),scale(df[,4:6])))
    y<-scale(df$beta)
    mean_beta<-mean(df$beta)
    sd_beta<-sd(df$beta)
    mean_pcs<-apply(as.matrix(df[,4:6]),2,mean)
    sd_pcs<-apply(as.matrix(df[,4:6]),2,sd)
    lm1<-glmnet(df[,4:6],df[,1],weights = df$weights,alpha=0,lambda=c(0.01,0.5,1,5,10))
    ind_selection<-c(1,5)[c(IVs[i] %in% ss1_IV$snp, IVs[i] %in% ss5_IV$snp)]
    se_selection<-c(ss1$effectSe[ind],ss5$effectSe[ind])[c(IVs[i] %in% ss1_IV$snp, IVs[i] %in% ss5_IV$snp)]
    res<-tuned_ridge(c(0.01,0.5,1,5,10),coef(lm1)[,5])
    eta_biased<-res$eta
    lambda_final<-res$lambda
    eta_debiased<-eta_biased+lambda_final*ginv(t(X)%*%X+lambda_final*diag(4))%*%eta_biased
    eta_final<-eta_debiased
    new_X<-as.matrix(c(1,(as.numeric(df6[1,1:3])-mean_pcs)/sd_pcs))
    predict.betax[i]<-t(new_X)%*%eta_final*sd_beta+mean_beta
  }
  Gamma_adj<-filter(ss6,snp %in% IVs)
  Gamma_adj<-Gamma_adj[match(IVs,Gamma_adj$snp),]
  theta_adj<-sum(Gamma_adj$effect*predict.betax/Gamma_adj$effectSe^2)/sum((predict.betax^2)/Gamma_adj$effectSe^2)
  se_adj<-sqrt(1/sum((predict.betax^2)/Gamma_adj$effectSe^2))
  
  ########################### meta regression only ################################
  predict.betax2<-numeric(length(IVs))
  se.predict2<-numeric(length(IVs))
  names(predict.betax2)<-IVs
  i<-1
  for (i in 1:length(predict.betax2)){
    ind<-which(ss1$snp==IVs[i])
    df<-data.frame(beta=c(ss1$effect[ind],ss2$effect[ind],ss3$effect[ind],ss4$effect[ind],ss5$effect[ind]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3],
                   weights=c(1/ss1$effectSe[ind]^2,1/ss2$effectSe[ind]^2,1/ss3$effectSe[ind]^2,1/ss4$effectSe[ind]^2,1/ss5$effectSe[ind]^2))
    
    lm1<-glmnet(df[,2:4],df[,1],weights = df$weights,alpha=0,lambda=c(0.01,0.5,1,5,10))
    b1<-predict(lm1,newx=as.matrix(df6[1,]))[which.max(lm1$dev.ratio)]
    predict.betax2[i]<-b1
  }
  
  Gamma_meta<-filter(ss6,snp %in% IVs)
  Gamma_meta<-Gamma_meta[match(IVs,Gamma_meta$snp),]
  theta_meta<-sum(Gamma_meta$effect*predict.betax2/Gamma_meta$effectSe^2)/sum((predict.betax2^2)/Gamma_meta$effectSe^2)
  se_meta<-sqrt(1/sum((predict.betax2^2)/Gamma_meta$effectSe^2))
  
  #################################default method, two sample#############################################
  snp_available<-intersect(ss6$snp,ss1_IV$snp)
  ss6_IV <- ss6 %>% filter(snp %in% snp_available)
  ss1_IV <- ss1_IV %>% filter(snp %in% snp_available)
  theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss1_IV[match(ss1_IV$snp,snp_available),]$effect
  se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss1_IV[match(ss1_IV$snp,snp_available),]$effect)
  theta.2S.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
  se.2S.default<-sqrt(1/sum(ss1_IV[match(ss1_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
  
  ################################# default method, three-sample #############################################
  snp_available<-intersect(ss6$snp,ss7_IV$snp)
  ss6_IV <- ss6 %>% filter(snp %in% snp_available)
  ss1_IV <- ss1 %>% filter(snp %in% snp_available)
  theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss1_IV[match(ss1_IV$snp,snp_available),]$effect
  se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss1_IV[match(ss1_IV$snp,snp_available),]$effect)
  theta.3S.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
  se.3S.default<-sqrt(1/sum(ss1_IV[match(ss1_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
  
  opdf[kk,]<-c(theta_adj,se_adj,theta_meta,se_meta,theta.2S.default,se.2S.default,theta.3S.default,se.3S.default)
  save(opdf,file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/normalMR/wc2_effect005_snpfile_res_betaZX_diff=",x,".RData"))
}
