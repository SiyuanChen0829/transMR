library(GENESIS,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(GWASTools,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")

args = commandArgs(trailingOnly=TRUE)
x = as.numeric(args[1])
x<-x/2
library(dplyr)
snpfile<-read.delim("/storage/group/dxl46/default/private/siyuan/MR/SNP.txt", header = TRUE, sep = "\t", dec = ".")
snpfile<-na.omit(snpfile)
snpfile<-snpfile %>% mutate(SNP=paste0(CHR,":",BP))
snpfile<-unique(snpfile,by="RSID")


load("/storage/group/dxl46/default/private/siyuan/MR/ref_AF_hg19.RData")
ref_AF <- ref %>% mutate(SNP=paste0(CHROM,":",POS))
ref_AF$EAS_AF<-as.numeric(ref_AF$EAS_AF)
ref_AF$AMR_AF<-as.numeric(ref_AF$AMR_AF)
ref_AF$AFR_AF<-as.numeric(ref_AF$AFR_AF)
ref_AF$EUR_AF<-as.numeric(ref_AF$EUR_AF)
ref_AF$SAS_AF<-as.numeric(ref_AF$SAS_AF)
ref_AF<-na.omit(ref_AF)
ref_AF<-ref_AF %>% filter(EAS_AF+EUR_AF+AFR_AF>0.1)

snpfile <-snpfile %>%filter(SNP %in% ref_AF$SNP)

set.seed(200)
snpfile<-snpfile[,1:7]
colnames(snpfile)<-c("SNP","CHR","BP","RSID","Freq_EUR","Freq_AFR","Freq_ASN")

#############################check for REF/ALT consistency
i<-1
for (i in 1:nrow(snpfile)){
  if(any((as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])>=0.98)&(as.numeric(snpfile[i,c(5:7)])+as.numeric(ref_AF[i,c(9,8,6)])<=1.02))){
    snpfile[i,c(5:7)]<-1-snpfile[i,c(5:7)]
    #print(i)
  }
}

n<-5000
colsAF<-c("Freq_EUR","Freq_AFR","Freq_ASN")
d<-c(0,x,2*x,0.5*x,1.5*x)

library(glmnet)
generatecohort<-function(n,i_ans,diffx,cvind,eps){
  cohort1<-data.frame(matrix(ncol=nrow(snpfile)+2,nrow=n, dimnames=list(NULL, c(snpfile$SNP,"Y","X"))))
  i<-1
  af<-snpfile[[i_ans]]
  for(i in 1:nrow(snpfile)){
    cohort1[,i]<-sample(c(0,1,2),size=n,replace=TRUE,prob=c(max(0,1-af[i]-af[i]^2),af[i],af[i]^2))
  }
  U<-rnorm(n,-0.5,2)
  cohort1$X<-rowSums((true_causal_effects_SNP[cvind]+diffx*eps[[i_ans]][cvind])*scale(cohort1[,ind_causal[cvind]]))+0.1*U+rnorm(n)
  #cohort1$X<-rowSums((true_causal_effects_SNP[cvind]+diffx*rnorm(length(true_causal_effects_SNP[cvind]),0,0.25))*cohort1[,ind_causal[cvind]])+0.1*U+rnorm(n)
  cohort1$Y<-0.1*cohort1$X+rnorm(n)+0.1*U
  return(cohort1)
}

e1<-numeric(10000)
e2<-numeric(10000)
e3<-numeric(10000)

se1<-numeric(10000)
se2<-numeric(10000)
se3<-numeric(10000)

#load(paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/normalMR/effect01_snpfile_res_betaZX_diff=",x,".RData"))
#last_iter<-which(rowSums(bbbb)==0)[1]
#kk<-last_iter
kk<-1
for (kk in 1:10000){
#for (kk in last_iter:10000){
  ind_causal<-sample(1:nrow(snpfile),25)
  cvind.m<-matrix(c(sample(1:25,20),sample(1:25,20),sample(1:25,20)),nrow=3)
  true_causal_effects_SNP<-abs(0.1+rnorm(length(ind_causal),0,0.05))
  rownames(cvind.m)<-colsAF
  eps.l<-list()
  eps.l[["Freq_EUR"]]<-rep(0,length(true_causal_effects_SNP))
  eps.l[["Freq_AFR"]]<-rnorm(length(true_causal_effects_SNP),0,0.05*d[2])
  eps.l[["Freq_ASN"]]<-rnorm(length(true_causal_effects_SNP),0,0.05*d[3])
  ng<-1
  for(ng in 1:25){
    c1<-generatecohort(n,colsAF[1],d[1],cvind.m[colsAF[1],],eps.l)
    c2<-generatecohort(n,colsAF[2],d[2],cvind.m[colsAF[2],],eps.l)
    c3<-generatecohort(n,colsAF[3],d[3],cvind.m[colsAF[3],],eps.l)
    c4<-generatecohort(n,colsAF[1],d[1],cvind.m[colsAF[1],],eps.l)
    c5<-generatecohort(n,colsAF[3],d[3],cvind.m[colsAF[3],],eps.l)
    c6<-generatecohort(n,colsAF[1],d[1],cvind.m[colsAF[1],],eps.l)
    source("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/standard_GWAS6.R")
  #  cat(paste0("cohort generation iter=",ng," at ", Sys.time(),"\n"),
  #     file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/timerecordfile_diff=",x),append=TRUE)
    if(all(c(nrow(ss1_IV),nrow(ss2_IV),nrow(ss3_IV),nrow(ss4_IV),nrow(ss5_IV))>=1)&(nrow(ss1_IV)>=3)){break}
  }
  #cat(paste0("iter=",kk," at ", Sys.time(),"\n",
  #           "SNP effect range for cohort 1:",min(ss1$effect,na.rm = TRUE),"-",max(ss1$effect,na.rm = TRUE),"\n",
  #           "SNP effect range for cohort 6:",min(ss6$effect,na.rm = TRUE),"-",max(ss6$effect,na.rm = TRUE),"\n"),
  #    file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_accuracy/timerecordfile_diff=",x),append=TRUE)
  
  
  snpfile<-snpfile%>%mutate(SNPname=paste0("X",CHR,".",BP))
  ref_AF<-ref_AF%>%mutate(SNPname=paste0("X",CHROM,".",POS))
  snpfile<-snpfile[match(snpfile$SNPname,ref_AF$SNPname),]
  snp_causal<-snpfile$SNPname[ind_causal]
  ind<-match(ss1$snp,ref_AF$SNPname)
  AF3<-ref_AF[ind,6:10]
  AF4<-t(AF3)
  aa<-rbind(ss1$allFreq,ss2$allFreq,ss3$allFreq,ss4$allFreq,ss5$allFreq,ss6$allFreq,AF4)
  pca<-prcomp(aa,center=TRUE,scale=TRUE)
  df6<-data.frame(pc1=pca[["x"]][6,1],pc2=pca[["x"]][6,2],pc3=pca[["x"]][6,3])
  
  i<-1
  predict.betax<-numeric(ncol(aa))
  names(predict.betax)<-ss1$snp
  for (i in 1:length(predict.betax)){
    df<-data.frame(beta=c(ss1$effect[i],ss2$effect[i],ss3$effect[i],ss4$effect[i],ss5$effect[i]),
                   pc1=pca[["x"]][1:5,1],
                   pc2=pca[["x"]][1:5,2],
                   pc3=pca[["x"]][1:5,3],
                   weights=c(1/ss1$effectSe[i]^2,1/ss2$effectSe[i]^2,1/ss3$effectSe[i]^2,1/ss4$effectSe[i]^2,1/ss5$effectSe[i]^2))
    
    #lm1<-lm(beta~pc1+pc2+pc3,weights = weights, data = df)
    #b1<-predict(lm1,newdata=df6)
    lm1<-glmnet(df[,2:4],df[,1],weights = df$weights,alpha=0,lambda=c(0.01,0.5,1))
    b1<-predict(lm1,newx=as.matrix(df6[1,]))[which.max(lm1$dev.ratio)]
    predict.betax[i]<-b1
  }
  
  ##################matched ancestry to select IV#############################################
  predict.betax2<-predict.betax[which(names(predict.betax) %in% unique(c(ss1_IV$snp,ss4_IV$snp)))]
  ss6_IV2 <- ss6_IV  %>% filter(snp %in% intersect(ss6_IV$snp,names(predict.betax2)))
  predict.betax2 <- predict.betax2[ss6_IV2$snp]
  theta.j<-ss6_IV2$effect/predict.betax2
  se_theta.j<-abs(ss6_IV2$effectSe/predict.betax2)
  theta.IVN<-sum(theta.j/(se_theta.j^2))/(sum(1/se_theta.j^2))
  se.IVN<-sqrt(1/sum(predict.betax2^2/ss6_IV2$effectSe^2))
  ############################################################################################ 
  
  #################################default method#############################################
  if (nrow(ss4_IV)<nrow(ss1_IV)){
    snp_available<-intersect(ss6_IV$snp,ss1_IV$snp)
    ss6_IV <- ss6 %>% filter(snp %in% snp_available)
    ss1_IV <- ss1_IV %>% filter(snp %in% snp_available)
    theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss1_IV[match(ss1_IV$snp,snp_available),]$effect
    se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss1_IV[match(ss1_IV$snp,snp_available),]$effect)
    theta.IVN.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
    se.default<-sqrt(1/sum(ss1_IV[match(ss1_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
  }
  if(nrow(ss4_IV)>nrow(ss1_IV)){
    snp_available<-intersect(ss6_IV$snp,ss4_IV$snp)
    ss6_IV <- ss6 %>% filter(snp %in% snp_available)
    ss4_IV <- ss4_IV %>% filter(snp %in% snp_available)
    theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss4_IV[match(ss4_IV$snp,snp_available),]$effect
    se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss4_IV[match(ss4_IV$snp,snp_available),]$effect)
    theta.IVN.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
    se.default<-sqrt(1/sum(ss4_IV[match(ss4_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
  }
  if(nrow(ss4_IV)==nrow(ss1_IV)){
    if(mean(ss1_IV$strength,na.omit=TRUE)>mean(ss4_IV$strength,na.omit=TRUE)){
      snp_available<-intersect(ss6_IV$snp,ss1_IV$snp)
      ss6_IV <- ss6 %>% filter(snp %in% snp_available)
      ss1_IV <- ss1_IV %>% filter(snp %in% snp_available)
      theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss1_IV[match(ss1_IV$snp,snp_available),]$effect
      se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss1_IV[match(ss1_IV$snp,snp_available),]$effect)
      theta.IVN.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
      se.default<-sqrt(1/sum(ss1_IV[match(ss1_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
    }else{
      snp_available<-intersect(ss6_IV$snp,ss4_IV$snp)
      ss6_IV <- ss6 %>% filter(snp %in% snp_available)
      ss4_IV <- ss4_IV %>% filter(snp %in% snp_available)
      theta.j.default<-ss6_IV[match(ss6_IV$snp,snp_available),]$effect/ss4_IV[match(ss4_IV$snp,snp_available),]$effect
      se_theta.j.default<-abs(ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe/ss4_IV[match(ss4_IV$snp,snp_available),]$effect)
      theta.IVN.default<-sum(theta.j.default/(se_theta.j.default^2))/(sum(1/se_theta.j.default^2))
      se.default<-sqrt(1/sum(ss4_IV[match(ss4_IV$snp,snp_available),]$effect^2/ss6_IV[match(ss6_IV$snp,snp_available),]$effectSe^2))
    }
  }
  ############################################################################################ 
  
  ##########################relax p-value,select IV across all cohorts########################
  theta.IVN3<-0
  se.IVN3<-0
  source("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/relaxpvalue.R")
  pr<-relax_p(ss2,ss3,ss5)
  if(pr!=0){
    ss2_IV_new<-filter(ss2,pValue<=pr)
    ss3_IV_new<-filter(ss3,pValue<=pr)
    ss5_IV_new<-filter(ss5,pValue<=pr)
    ind_available<-intersect(intersect(ss2_IV_new$snp,ss3_IV_new$snp),ss5_IV_new$snp)
    ind_available<-unique(c(ind_available,snp_available))
    ss6_IV3 <- ss6 %>% filter(snp %in% ind_available)
    
    tt<-ss1[which(ss1$snp %in% ss6_IV3$snp),]
    tt$IVstrength<-tt$effect^2/tt$effectSe^2
    tt<-tt[which(tt$IVstrength>=10),]
    
    vv<-ss4[which(ss4$snp %in% ss6_IV3$snp),]
    vv$IVstrength<-vv$effect^2/vv$effectSe^2
    vv<-vv[which(vv$IVstrength>=10),]
    
    ind_available<-ind_available[which(ind_available%in%unique(c(tt$snp,vv$snp)))]
    predict.betax3<-predict.betax[which(names(predict.betax) %in% ind_available)]
    ss6_IV3 <- ss6 %>% filter(snp %in% ind_available)
    predict.betax3 <- predict.betax3[ss6_IV3$snp]
    theta.j3<-ss6_IV3$effect/predict.betax3
    se_theta.j3<-abs(ss6_IV3$effectSe/predict.betax3)
    theta.IVN3<-sum(theta.j3/(se_theta.j3^2))/(sum(1/se_theta.j3^2))
    se.IVN3<-sqrt(1/sum(predict.betax3^2/ss6_IV3$effectSe^2))
  }
  e1[kk]<-theta.IVN
  e2[kk]<-theta.IVN.default
  e3[kk]<-theta.IVN3
  se1[kk]<-se.IVN
  se2[kk]<-se.default
  se3[kk]<-se.IVN3
  bbbb<-data.frame(est1=e1,est_default=e2,est2=e3,se1=se1,se2=se2,se3=se3)
    bbbb$est1[kk]<-theta.IVN
    bbbb$est_default[kk]<-theta.IVN.default
    bbbb$est2[kk]<-theta.IVN3
    bbbb$se1[kk]<-se.IVN
    bbbb$se2[kk]<-se.default
    bbbb$se3[kk]<-se.IVN3
  save(bbbb,file=paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/normalMR/effect01_snpfile_res_betaZX_diff=",x,".RData"))
}
