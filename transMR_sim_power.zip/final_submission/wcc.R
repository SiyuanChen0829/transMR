ridge_log_likelihood <- function(w, X, y, lambda = 0.1, weights) {
  n <- length(y)
  residuals <- y - X %*% w
  weighted_residuals_sq <- weights * (residuals^2)
  sigma2 <- sum(weighted_residuals_sq) / sum(weights)
  prob<-rep(1,n)
  w_c<-w+lambda*ginv(t(X)%*%X+lambda*diag(4))%*%w
  mu1<-(X[ind_selection,] %*% w_c)*sd_beta+mean_beta
  c<-qnorm(1-(1e-3)/2)
  prob[ind_selection]<-pnorm(-c+mu1/se_selection)+pnorm(-c-mu1/se_selection)
  return(-(-n/2*log(2*pi*sigma2)-sum(weights*(residuals^2/2/sigma2+log(prob)))-(lambda/2)*sum(w[-1]^2)))
}

tuned_ridge<-function(lambda_vec, initial_eta){
  null_deviance<-sum((y-mean(y))^2)
  d<-numeric(length(lambda_vec))
  etas<-list()
  i<-1
  for (i in 1:length(lambda_vec)){
    fit_ridge<-optim(initial_eta,fn=ridge_log_likelihood,X = X,y = y,
                     lambda = lambda_vec[i],weights=df$weights/sum(df$weights)*length(df$weights),
                     method = 'BFGS')
    eta<-fit_ridge$par
    fitted_values<-X %*% eta
    model_deviance<-sum((y-fitted_values)^2)
    dev_ratio<- 1-(model_deviance/null_deviance)
    etas[[i]]<-eta
    d[i]<-dev_ratio
  }
  res<-list(lambda=lambda_vec[which.max(d)],
            eta=etas[[which.max(d)]])
  return(res)
}
