relax_p<-function(ss2,ss3,ss5){
  p_thres<-c(1e-5,1e-4,1e-3,1e-2,0.05)
  for(pp in p_thres){
  ss2_IV<-filter(ss2,pValue<=pp)
  ss3_IV<-filter(ss3,pValue<=pp)
  ss5_IV<-filter(ss5,pValue<=pp)
  ind_available<-intersect(intersect(ss2_IV$snp,ss3_IV$snp),ss5_IV$snp)
  if(length(ind_available)>=5){break}
  }
  if(length(ind_available)==0){pp<-0}
  return(pp)
}


relax_p_multi<-function(ss1,ss2,ss3,ss4,ss5){
  p_thres<-c(1e-5,5e-5,1e-4,5e-4,1e-3,5e-3,1e-2)
  for(pp in p_thres){
    ss1_IV<-filter(ss1,pValue<=pp)
    ss2_IV<-filter(ss2,pValue<=pp)
    ss3_IV<-filter(ss3,pValue<=pp)
    ss4_IV<-filter(ss4,pValue<=pp)
    ss5_IV<-filter(ss5,pValue<=pp)
    ind_available<-intersect(intersect(ss2_IV$snp,ss3_IV$snp),ss5_IV$snp)
    ind_available<-intersect(intersect(ss1_IV$snp,ss4_IV$snp),ind_available)
    if(length(ind_available)>=3){break}
  }
  if(length(ind_available)==0){pp<-0}
  return(pp)
}
