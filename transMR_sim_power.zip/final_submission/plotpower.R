df1<-data.frame(phi=c(0,0.5,1,1.5),transMR=0,IVW=0,transMR_globalIV=0)
for (x in df1$phi){
load(paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/normalMR/effect01_snpfile_res_betaZX_diff=",x,".RData"))
ind<-which(df1$phi==x)
bbbb$t1<-bbbb$est1^2/bbbb$se1^2
bbbb$t2<-bbbb$est_default^2/bbbb$se2^2
bbbb$t3<-bbbb$est2^2/bbbb$se3^2
bbbb<-na.omit(bbbb)
df1$transMR[ind]<-sum(bbbb$t1>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
df1$IVW[ind]<-sum(bbbb$t2>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
df1$transMR_globalIV[ind]<-sum(bbbb$t3>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
}

df2<-data.frame(phi=c(0,0.5,1,1.5),transMR=0,IVW=0,transMR_globalIV=0)
for (x in df2$phi){
  load(paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/weakIV/effect01_snpfile_res_betaZX_diff=",x,".RData"))
  ind<-which(df2$phi==x)
  bbbb$t1<-bbbb$est1^2/bbbb$se1^2
  bbbb$t2<-bbbb$est_default^2/bbbb$se2^2
  bbbb$t3<-bbbb$est2^2/bbbb$se3^2
  bbbb<-na.omit(bbbb)
  df2$transMR[ind]<-sum(bbbb$t1>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df2$IVW[ind]<-sum(bbbb$t2>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df2$transMR_globalIV[ind]<-sum(bbbb$t3>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
}

df2<-data.frame(phi=c(0,0.5,1,1.5),transMR=0,IVW=0,transMR_globalIV=0,scenario=NA)
for (x in df2$phi){
  load(paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/ss10k_effect01_weakIV_snpfile_res_betaZX_diff=",x,".RData"))
  ind<-which(df2$phi==x)
  bbbb$t1<-bbbb$est1^2/bbbb$se1^2
  bbbb$t2<-bbbb$est_default^2/bbbb$se2^2
  bbbb$t3<-bbbb$est2^2/bbbb$se3^2
  df2$transMR[ind]<-sum(bbbb$t1>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df2$IVW[ind]<-sum(bbbb$t2>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df2$transMR_globalIV[ind]<-sum(bbbb$t3>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df2$scenario[ind]<-"B"
}

df3<-expand.grid(phi=c(0,0.5,1,1.5),transMR=0,IVW=0,transMR_globalIV=0,fraction=c("05","025","01","005"))
i<-1
for (i in 1:nrow(df3)){
  file<-list.files(path="/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/underrepresent/",
                   pattern=paste0("fraction_AFR",df3$fraction[i],".*_diff=",df3$phi[i],".RData"))
  load(paste0("/storage/group/dxl46/default/private/siyuan/MR/multi_single_power/final_submission/underrepresent/",file))
  bbbb$t1<-bbbb$est1^2/bbbb$se1^2
  bbbb$t2<-bbbb$est_default^2/bbbb$se2^2
  bbbb$t3<-bbbb$est2^2/bbbb$se3^2
  bbbb<-na.omit(bbbb)
  df3$transMR[i]<-sum(bbbb$t1>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df3$IVW[i]<-sum(bbbb$t2>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
  df3$transMR_globalIV[i]<-sum(bbbb$t3>qchisq(0.95,1),na.rm=TRUE)/nrow(bbbb)
}

library(ggplot2)
library(ggsci)
library(reshape2)
library(patchwork)
bb<-melt(df1,id.vars=c(1))
colnames(bb)<-c("phi","method","power")
bb2<-melt(df2,id.vars=c(1))
colnames(bb2)<-c("phi","method","power")

g1<-ggplot(bb, aes(x = phi,  y = power, color=method)) +
  geom_line()+
  geom_point()+
  theme_bw()+
  scale_color_npg()+ theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

g2<-ggplot(bb2, aes(x = phi,  y = power, color=method)) +
  geom_line()+
  geom_point()+
  theme_bw()+
  scale_color_npg()+ theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

g1+g2

levels(df3$fraction) <- c("0.5", "0.25", "0.1", "0.05")
bb3<-melt(df3,id.vars=c(1,5))
colnames(bb3)<-c("phi","fraction","method","power")

ggplot(bb3, aes(x = phi,  y = power, color=method)) +
  geom_line()+
  geom_point()+
  theme_bw()+
  facet_wrap(~fraction)+
  scale_color_npg()+ theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

