istudy = 2

getest.default<-function(bzx,bzx_se,bzy_se,ldrho.m,bzy,topsnp_index, single_snp_heidi_thresh=0.01){
  cov_bxy = cov_bXY(bzx, bzx_se, bzy, bzy_se, ldrho.m);
  bxy = bzy/bzx
  d = bxy - bxy[topsnp_index]
  var_d = diag(cov_bxy) + diag(cov_bxy)[topsnp_index] - 2*cov_bxy[topsnp_index,]
  var_d[topsnp_index] = 1 
  heidi_pval = pchisq(d^2/var_d, 1, lower.tail=F)
  kept_index = which(heidi_pval >= single_snp_heidi_thresh)
  # update summary stats
  bzx = bzx[kept_index]; bzx_se = bzx_se[kept_index]; bzx_pval = bzx_pval[kept_index];
  bzy = bzy[kept_index]; bzy_se = bzy_se[kept_index]; ldrho.m = ldrho.m[kept_index, kept_index];
  snpids<-snpids[kept_index]; sub_eqtl<-sub_eqtl[kept_index,];sub_gwas<-sub_gwas[kept_index,];
  
  bxy = bzy/bzx; bxy.se<-abs(bzy_se/bzx)
  theta.default<-sum(bxy/(bxy.se^2))/(sum(1/bxy.se^2))
  se.default<-sqrt(1/sum(bzx^2/bzy_se^2))
  return(c(theta.default,se.default,length(bxy)))
}

getest.IVN<-function(bzx,bzx_se,bzy_se,ldrho.m,bzy,topsnp_index,predict.beta,single_snp_heidi_thresh=0.01){
  cov_bxy = cov_bXY(bzx, bzx_se, bzy, bzy_se, ldrho.m);
  bxy = bzy/predict.beta; bxy.se<-abs(bzy_se/predict.beta); bxy.se.d<-abs(bzy_se/bzx)
  cov_bxy = cov_bxy/((bxy.se.d)%*%t(bxy.se.d))*((bxy.se)%*%t(bxy.se))
  d = bxy - bxy[topsnp_index]
  var_d = diag(cov_bxy) + diag(cov_bxy)[topsnp_index] - 2*cov_bxy[topsnp_index,]
  var_d[topsnp_index] = 1 
  heidi_pval = pchisq(d^2/var_d, 1, lower.tail=F)
  single_snp_heidi_thresh=0.01
  kept_index = which(heidi_pval >= single_snp_heidi_thresh)
  # update summary stats
  bzx = bzx[kept_index]; bzx_se = bzx_se[kept_index]; bzx_pval = bzx_pval[kept_index];
  bzy = bzy[kept_index]; bzy_se = bzy_se[kept_index]; ldrho.m = ldrho.m[kept_index, kept_index];
  snpids<-snpids[kept_index]; sub_eqtl<-sub_eqtl[kept_index,];sub_gwas<-sub_gwas[kept_index,];predict.beta<-predict.beta[kept_index];
  
  bxy = bzy/predict.beta; bxy.se<-abs(bzy_se/predict.beta)
  theta.default<-sum(bxy/(bxy.se^2))/(sum(1/bxy.se^2))
  se.default<-sqrt(1/sum(predict.beta^2/bzy_se^2))
  return(c(theta.default,se.default,length(bxy)))
}
library(MASS)
source("/storage/group/dxl46/default/private/siyuan/MR/Application/t1d/final_submission/utilities.R")

library(glmnet, lib.loc = "/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(dplyr)
library(data.table, lib.loc = "/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
source("/storage/group/dxl46/default/private/siyuan/MR/Application/gsmr.R")


type<-"PBMC"
##################
#load summary data
o.eqtl.EUR<-fread(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/sig_eqtl_EUR_",type,".txt"))
o.eqtl.AFR<-fread(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/sig_eqtl_AFA_",type,".txt"))
o.eqtl.HIS<-fread(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/sig_eqtl_HIS_",type,".txt"))
o.eqtl.CHN<-fread(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/main_sig_eqtl_CHN_",type,".txt"))

o.eqtl.CHN$id<-sapply(strsplit(o.eqtl.CHN$V1, split='_', fixed=TRUE), function(x) (x[1]))
load(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/refAF_eqtl_CHN.RData"))
library(rtracklayer,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")
library(SNPRelate,lib.loc="/storage/home/szc6287/R/x86_64-pc-linux-gnu-library/4.2")

load("/storage/group/dxl46/default/private/siyuan/MESA/cov_info.RData")
sampid.EUR<-unique(filter(cov_info_df,ancestry=="European")$NWD_ID)
sampid.AFA<-unique(filter(cov_info_df,ancestry=="African")$NWD_ID)
sampid.HIS<-unique(filter(cov_info_df,ancestry=="Hispanic Admixed")$NWD_ID)
sampid.CHN<-unique(filter(cov_info_df,ancestry=="East Asian")$NWD_ID)
chain <- import.chain("/storage/group/dxl46/default/private/siyuan/MR/Application/hg19ToHg38.over.chain")

gwas<-fread(paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/sle_eas",istudy,".txt"))
gwas<-as.data.frame(gwas)
colnames(gwas)<-c("variant_id","chromosome","base_pair_location","other_allele","effect_allele","allele_info","beta","standard_error","p_value")
gwas$z = gwas$beta/gwas$standard_error

hg19_coordinates <- GRanges(
  seqnames = paste0("chr",gwas$chromosome),
  ranges = IRanges(
    start = gwas$base_pair_location,
    end = gwas$base_pair_location
  )
)
names(hg19_coordinates)<-gwas$variant_id
hg38_coordinates <- liftOver(hg19_coordinates, chain)
bb<-as.data.frame(hg38_coordinates)
gwas$bpos2<-NA
i<-match(gwas$variant_id,bb$group_name)
if(any(is.na(i))){
  gwas<-gwas[-which(is.na(i)),]}
gwas$bpos2<-bb$start[match(bb$group_name,gwas$variant_id)]
gwas<-mutate(gwas, id=paste0("chr",chromosome,":",bpos2))
snp_ids<-intersect(o.eqtl.CHN$id,gwas$id)
gwas<-filter(gwas, id %in% snp_ids)
eqtl<-filter(o.eqtl.CHN, id %in% snp_ids)

harmonization<-data.frame(snp=gwas$id,a1=gwas$effect_allele,a2=gwas$other_allele)
harmonization$a1_eqtl<-sapply(eqtl$V1[match(harmonization$snp,eqtl$id)], function(x) strsplit(x, "_|/")[[1]][2])
harmonization$a2_eqtl<-sapply(eqtl$V1[match(harmonization$snp,eqtl$id)], function(x) strsplit(x, "_|/")[[1]][3])

i<-1
snp_ids<-character()
for (i in 1:nrow(harmonization)){
  if((harmonization$a1[i]==harmonization$a1_eqtl[i])&(harmonization$a2[i]==harmonization$a2_eqtl[i])){
    snp_ids<-c(snp_ids,harmonization$snp[i])
  }
  if((harmonization$a1[i]==harmonization$a2_eqtl[i])&(harmonization$a2[i]==harmonization$a1_eqtl[i])){
    snp_ids<-c(snp_ids,harmonization$snp[i])
    gwas$beta[i]<-(-gwas$beta[i])
    gwas$z[i]<-(-gwas$z[i])
    gwas$effect_allele[i]<-harmonization$a2_eqtl[i]
    gwas$other_allele[i]<-harmonization$a1_eqtl[i]
    gwas$freq[i]<-(1-gwas$freq[i])
  }
  
}
gwas<-filter(gwas, id %in% snp_ids)
eqtl<-filter(eqtl, id %in% snp_ids)
colnames(gwas)<-c("snpid","chr","bpos","a1","a2","allele_info","beta","se","pval","z","bpos2","id")
##################
#select IV for each gene, do HEIDI filter
genes<-unique(eqtl$V2)
output.df<-data.frame(genes=genes, n_IV_def=0,theta.default=0,se.default=0,
                      theta.IVN.0PC=0,se.IVN.0PC=0, n_IV.0PC=0,
                      theta.IVN.1PC=0,se.IVN.1PC=0, n_IV.1PC=0,
                      theta.IVN.2PC=0,se.IVN.2PC=0, n_IV.2PC=0,
                      chr=0)
j<-1
for (j in 1:length(genes)){
  gene<-genes[j]
  #gene<-"ENSG00000112685"
  sub_eqtl<-filter(eqtl, V2==gene)
  
  
  if (nrow(sub_eqtl)<3){next}
  
  sub_gwas<-filter(gwas, id %in% sub_eqtl$id)
  sub_gwas<-sub_gwas[match(sub_eqtl$id,sub_gwas$id),]
  output.df$chr[j]<-sub_gwas$chr[1]
  bzx<-sub_eqtl$V3
  bzx_se<-sub_eqtl$V3/sub_eqtl$V4
  bzx_pval<-sub_eqtl$V5
  bzy<-sub_gwas$beta
  bzy_se<-sub_gwas$se
  bzy_pval<-sub_gwas$pval
  
  gds <- snpgdsOpen(paste0("/storage/group/dxl46/default/private/siyuan/MESA/kingMat/freeze.6a.chr",sub_gwas$chr[1],".filter.gds"), readonly=FALSE, allow.duplicate=FALSE, allow.fork=TRUE)
  snp_id <- read.gdsn(index.gdsn(gds, "snp.id"))
  
  if(length(which(sub_eqtl$V1 %in% snp_id))<3){
    snpgdsClose(gds)
    next
  }
  
  source("/storage/group/dxl46/default/private/siyuan/MR/Application/af.R")
  
  ldrho<-snpgdsLDMat(gds, sample.id=sampid.CHN, snp.id=sub_eqtl$V1[which(sub_eqtl$V1 %in% snp_id)], slide=-1,
                     method="corr", mat.trim=FALSE,
                     num.thread=1L, with.id=TRUE, verbose=TRUE)
  ldrho.m<-ldrho$LD
  rownames(ldrho.m)<-ldrho$snp.id
  sub_eqtl<-filter(sub_eqtl,V1 %in% ldrho$snp.id)
  sub_gwas<-filter(sub_gwas, id %in% sub_eqtl$id)
  ldrho.m<-ldrho.m[match(sub_eqtl$V1,rownames(ldrho.m)),match(sub_eqtl$V1,rownames(ldrho.m))]
  
  
  bzx<-sub_eqtl$V3
  bzx_se<-sub_eqtl$V3/sub_eqtl$V4
  bzx_pval<-sub_eqtl$V5
  bzy<-sub_gwas$beta
  bzy_se<-sub_gwas$se
  bzy_pval<-sub_gwas$pval
  
  snpids<-sub_eqtl$id
  # filter dataset
  indx = snp_ld_prune(ldrho.m, sqrt(0.1))
  
  if(length(indx)>0) {
    #linkage_snps = snpIDp[indx]
    bzx = bzx[-indx]; bzx_se = bzx_se[-indx]; bzx_pval = bzx_pval[-indx];
    bzy = bzy[-indx]; bzy_se = bzy_se[-indx]; bzy_pval = bzy_pval[-indx];
    ldrho.m = ldrho.m[-indx, -indx];snpids<-snpids[-indx];
    sub_eqtl = sub_eqtl[-indx,];sub_gwas = sub_gwas[-indx,];
    #warning("There were SNPs in high LD. After LD pruning with a LD r2 threshold of ", ld_r2_thresh, ", ", length(indx), " SNPs were removed. Note: The threshold of LD can be changed by the \"ld_r2_thresh\".")
  }
  
  if(length(bzx)<2){
    snpgdsClose(gds)
    next
  }
  
  # HEIDI-outlier in Zhu et al. (Nature Communications, 2018)
  #na_snps<-resbuf$na_snps; weak_snps<-resbuf$weak_snps; linkage_snps<-resbuf$linkage_snps;
  topsnp_index = topsnp_bxy(bzx, bzx_pval, bzy);
  if(topsnp_index!=0){
    res<-getest.default(bzx,bzx_se,bzy_se,ldrho.m,bzy,topsnp_index)
    output.df$theta.default[j]<-res[1]
    output.df$se.default[j]<-res[2]
    output.df$n_IV_def[j]<-res[3]
  }
  
  npc<-1
  eqtl.AFR<-o.eqtl.AFR
  eqtl.AFR$id<-sapply(strsplit(eqtl.AFR$V1, split='_', fixed=TRUE), function(x) (x[1]))
  eqtl.AFR<-filter(eqtl.AFR,(id %in% sub_eqtl$id) & (V2 == gene))
  eqtl.AFR$se<-eqtl.AFR$V3/eqtl.AFR$V4
  
  eqtl.HIS<-o.eqtl.HIS
  eqtl.HIS$id<-sapply(strsplit(eqtl.HIS$V1, split='_', fixed=TRUE), function(x) (x[1]))
  eqtl.HIS<-filter(eqtl.HIS,(id %in% sub_eqtl$id) & (V2 == gene))
  eqtl.HIS$se<-eqtl.HIS$V3/eqtl.HIS$V4
  
  eqtl.EUR<-o.eqtl.EUR
  eqtl.EUR$id<-sapply(strsplit(eqtl.EUR$V1, split='_', fixed=TRUE), function(x) (x[1]))
  eqtl.EUR<-filter(eqtl.EUR,(id %in% sub_eqtl$id) & (V2 == gene))
  eqtl.EUR$se<-eqtl.EUR$V3/eqtl.EUR$V4
  
  sub_eqtl$se<-sub_eqtl$V3/sub_eqtl$V4
  available_IV<-intersect(eqtl.EUR$V1,intersect(eqtl.AFR$V1,eqtl.HIS$V1))
  
  if(length(available_IV)<2){
    snpgdsClose(gds)
    next
  }
  
  sub_eqtl<-filter(sub_eqtl,V1 %in% available_IV)
  sub_gwas<-filter(sub_gwas,id %in% sub_eqtl$id)
  eqtl.AFR<-eqtl.AFR[match(sub_eqtl$V1,eqtl.AFR$V1),]
  eqtl.HIS<-eqtl.HIS[match(sub_eqtl$V1,eqtl.HIS$V1),]
  eqtl.EUR<-eqtl.EUR[match(sub_eqtl$V1,eqtl.EUR$V1),]
  
  for(npc in 1:3){
    theta.IVN<-0
    se.IVN<-0
    nIV<-0
    source("/storage/group/dxl46/default/private/siyuan/MR/Application/t1d/final_submission/transMR.R")
    topsnp_index = topsnp_bxy(predict.betax,pvalue.predict, sub_gwas$beta);
    if(topsnp_index!=0){
      bzx<-sub_eqtl$V3
      bzx_se<-sub_eqtl$V3/sub_eqtl$V4
      bzx_pval<-sub_eqtl$V5
      bzy<-sub_gwas$beta
      bzy_se<-sub_gwas$se
      bzy_pval<-sub_gwas$pval
      ind<-which(!(rownames(ldrho.m) %in% sub_eqtl$V1))
      if(length(ind)>0){
        ldrho.m<-ldrho.m[-ind,-ind]}
      res<-getest.default(predict.betax,se.predict,bzy_se,ldrho.m,bzy,topsnp_index)
      theta.IVN<-res[1]
      se.IVN<-res[2]
      nIV<-res[3]
    }
    output.df[j,(2+npc*3):(4+npc*3)]<-c(theta.IVN,se.IVN,nIV)
  }
  snpgdsClose(gds)
  save(output.df,file=paste0("/storage/group/dxl46/default/private/siyuan/MR/Application/lupus/final_submission/CHN_sle_estimators_",istudy,"_BIC.RData"))
}
